var CoDen = {
	Tot: 'QuanCo/Tot_Den.png',
	Tuong: 'QuanCo/Tuong_Den.png',
	Ma: 'QuanCo/Ma_Den.png',
	Xe: 'QuanCo/Xe_Den.png',
	Hau: 'QuanCo/Hau_Den.png',
	Vua: 'QuanCo/Vua_Den.png',
	Rong: "QuanCo/Rong.png",
	// Name
	Tot_Name: 'Tot_Den',
	Tuong_Name: 'Tuong_Den',
	Ma_Name: 'Ma_Den',
	Xe_Name: 'Xe_Den',
	Hau_Name: 'Hau_Den',
	Vua_Name: 'Vua_Den'
}

var CoDo = {
	Tot: 'QuanCo/Tot_Do.png',
	Tuong: 'QuanCo/Tuong_Do.png',
	Ma: 'QuanCo/Ma_Do.png',
	Xe: 'QuanCo/Xe_Do.png',
	Hau: 'QuanCo/Hau_Do.png',
	Vua: 'QuanCo/Vua_Do.png',
	Rong: "QuanCo/Rong.png",
	// Name
	Tot_Name: 'Tot_Do',
	Tuong_Name: 'Tuong_Do',
	Ma_Name: 'Ma_Do',
	Xe_Name: 'Xe_Do',
	Hau_Name: 'Hau_Do',
	Vua_Name: 'Vua_Do'
}

var Mau = {
	Trang: "255,255,255",
	Den: "170,182,155",
	NuocDi: "246,205,97"
}