function Hau(id){
	Tuong(id);
	Xe(id);
}